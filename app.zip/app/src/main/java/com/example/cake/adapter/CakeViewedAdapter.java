package com.example.cake.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.cake.R;
import com.example.cake.entity.CakeViewed;
import com.example.cake.activity.CakeDetailActivit;

import java.util.List;

public class CakeViewedAdapter extends RecyclerView.Adapter<CakeViewedAdapter.RecentlyViewedViewHolder> {

    Context context;
    List<CakeViewed> cakeViewedList;
    private Bitmap bitmap;
    private Bitmap imgBitmap = null;

    public CakeViewedAdapter(Context context, List<CakeViewed> cakeViewedList) {
        this.context = context;
        this.cakeViewedList = cakeViewedList;
    }

    @NonNull
    @Override
    public RecentlyViewedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.cake_viewed_items, parent, false);
        return new RecentlyViewedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecentlyViewedViewHolder holder, int position) {

        holder.dg.setText((CharSequence) cakeViewedList.get(position).getdg());

        String url = (String) cakeViewedList.get(position).getimg();
        Glide.with(holder.simg.getContext()).asBitmap().load(url).into(new CustomTarget<Bitmap>() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                imgBitmap = resource;
                holder.simg.setImageBitmap(imgBitmap);
            }
            @Override
            public void onLoadCleared(@Nullable Drawable placeholder) {

            }
        });

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(context, CakeDetailActivit.class);
                i.putExtra("name", (CharSequence) cakeViewedList.get(position).getName());
                i.putExtra("dg", (CharSequence) cakeViewedList.get(position).getdg());
                i.putExtra("price", (CharSequence) cakeViewedList.get(position).getprice());
                i.putExtra("image", (String) cakeViewedList.get(position).getimg());
                i.putExtra("kucun", (CharSequence) cakeViewedList.get(position).getkucun());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return cakeViewedList.size();
    }

    public  static class RecentlyViewedViewHolder extends RecyclerView.ViewHolder{

        TextView name,dg;
        ImageView simg;

        public RecentlyViewedViewHolder(@NonNull View itemView) {
            super(itemView);

            dg = itemView.findViewById(R.id.product_name);
            simg = itemView.findViewById(R.id.simg);
        }
    }

}