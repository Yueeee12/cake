package com.example.cake.entity;

public class OrderViewed {

    Object name;
    Object shangpin;
    Object price;
    Object time;

    public OrderViewed(Object name, Object shangpin, Object price, Object time) {
        this.name = name;
        this.shangpin = shangpin;
        this.price = price;
        this.time = time;
    }

    public Object getName() {
        return name;
    }

    public void setName(Object name) {
        this.name = name;
    }

    public Object getshangpin() {
        return shangpin;
    }

    public void setshangpin(Object shangpin) {
        this.shangpin = shangpin;
    }

    public Object getprice() {
        return price;
    }

    public void setprice(Object price) {
        this.price = price;
    }

    public Object gettime() {
        return time;
    }

    public void settime(Object time) {
        this.time = time;
    }

}
