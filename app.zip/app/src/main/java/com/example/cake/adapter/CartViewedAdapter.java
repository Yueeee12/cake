package com.example.cake.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.cake.entity.CartViewed;
import com.example.cake.R;

import java.util.List;

public class CartViewedAdapter extends RecyclerView.Adapter<CartViewedAdapter.RecentlyViewedViewHolder> {

    Context context;
    List<CartViewed> RecentlyViewedList;
    private Bitmap imgBitmap = null;

    public CartViewedAdapter(Context context, List<CartViewed> RecentlyViewedList) {
        this.context = context;
        this.RecentlyViewedList = RecentlyViewedList;
    }
    
    @NonNull
    @Override
    public CartViewedAdapter.RecentlyViewedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.cart_viewed_items, parent, false);
        return new CartViewedAdapter.RecentlyViewedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecentlyViewedViewHolder holder, int position) {
        CartViewed item = RecentlyViewedList.get(position);
        //holder.name.setText((CharSequence) RecentlyViewedList.get(position).getName());
        holder.dg.setText((CharSequence) RecentlyViewedList.get(position).getdg());
        holder.price.setText((CharSequence) RecentlyViewedList.get(position).getprice());
        String url = (String) RecentlyViewedList.get(position).getimg();
        Glide.with(holder.simg.getContext()).asBitmap().load(url).into(new CustomTarget<Bitmap>() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                imgBitmap = resource;
                holder.simg.setImageBitmap(imgBitmap);
            }
            @Override
            public void onLoadCleared(@Nullable Drawable placeholder) {

            }
        });

        holder.num.setText(String.valueOf(RecentlyViewedList.get(position).getNum()));
        holder.item_btn_add.setOnClickListener(v -> {
            int newValue = item.getNum() + 1;
            item.setNum(newValue);
            holder.num.setText(String.valueOf(newValue));
            notifyItemChanged(position); // 更新该项
            // 更新总和
            updateTotalSum();
        });
        holder.item_btn_sub.setOnClickListener(v -> {
            int newValue = item.getNum() - 1;
            item.setNum(newValue);
            holder.num.setText(String.valueOf(newValue));
            notifyItemChanged(position); // 更新该项
            // 更新总和
            updateTotalSum();
        });

        holder.checkBox.setOnClickListener(v -> {
            item.setChecked(holder.checkBox.isChecked());
            notifyItemChanged(position); // 更新该项
            // 更新总和
            updateTotalSum();
        });

    }

    // 用于更新总和的回调接口
    public interface TotalSumListener {
        void onTotalSumChanged(double totalSum);
    }

    private TotalSumListener totalSumListener;

    public void setTotalSumListener(TotalSumListener listener) {
        this.totalSumListener = listener;
    }

    private void updateTotalSum() {
        if (totalSumListener != null) {
            totalSumListener.onTotalSumChanged(calculateTotalSum());
        }
    }

    // 计算所有项的num乘以price的总和
    public double calculateTotalSum() {
        double totalSum = 0;

        for (CartViewed item : RecentlyViewedList) {
            try {
                double priceDouble = Double.parseDouble(item.getprice());
                totalSum += item.getNum() * priceDouble;
            } catch (NumberFormatException e) {
                // 处理价格格式错误
            }
        }
        return totalSum;
    }


    @Override
    public int getItemCount() {
        return RecentlyViewedList.size();
    }

    public  static class RecentlyViewedViewHolder extends RecyclerView.ViewHolder{

        TextView dg,price,num,item_btn_add,item_btn_sub;
        ImageView simg;
        CheckBox checkBox;

        public RecentlyViewedViewHolder(@NonNull View itemView) {
            super(itemView);

            dg = itemView.findViewById(R.id.dg);
            price = itemView.findViewById(R.id.pri);
            simg = itemView.findViewById(R.id.img);
            num = itemView.findViewById(R.id.tv_num);
            item_btn_add = itemView.findViewById(R.id.tv_add);
            item_btn_sub = itemView.findViewById(R.id.tv_reduce);
            checkBox = itemView.findViewById(R.id.check_box);
        }
    }

}