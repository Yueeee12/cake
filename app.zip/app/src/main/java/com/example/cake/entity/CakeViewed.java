package com.example.cake.entity;

public class CakeViewed {

    Object name;
    Object dg;
    Object price;
    Object img;
    Object kucun;

    public CakeViewed(Object name, Object dg, Object price, Object img, Object kucun) {
        this.name = name;
        this.dg = dg;
        this.img = img;
        this.price = price;
        this.kucun = kucun;
    }

    public Object getName() {
        return name;
    }

    public void setName(Object name) {
        this.name = name;
    }

    public Object getdg() {
        return dg;
    }

    public void setdg(Object dg) {
        this.dg = dg;
    }

    public Object getprice() {
        return price;
    }

    public void setprice(Object price) {
        this.price = price;
    }

    public Object getkucun() {
        return kucun;
    }

    public void setkucun(Object kucun) {
        this.kucun = kucun;
    }

    public Object getimg() {
        return img;
    }

    public void setimg(Object simg) {
        this.img = img;
    }



}