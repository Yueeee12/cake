package com.example.cake.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.cake.entity.OrderViewed;
import com.example.cake.activity.OrderDetailActivity;
import com.example.cake.R;

import java.util.List;

public class OrderViewedAdapter extends RecyclerView.Adapter<OrderViewedAdapter.RecentlyViewedViewHolder> {

    Context context;
    List<OrderViewed> RecentlyViewedList;
    private Bitmap bitmap;
    private Bitmap imgBitmap = null;

    public OrderViewedAdapter(Context context, List<OrderViewed> RecentlyViewedList) {
        this.context = context;
        this.RecentlyViewedList = RecentlyViewedList;
    }

    @NonNull
    @Override
    public OrderViewedAdapter.RecentlyViewedViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.order_viewed_items, parent, false);
        return new OrderViewedAdapter.RecentlyViewedViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewedAdapter.RecentlyViewedViewHolder holder, final int position) {

        holder.shangpin.setText((CharSequence) RecentlyViewedList.get(position).getshangpin());
        holder.price.setText((CharSequence) RecentlyViewedList.get(position).getprice());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(context, OrderDetailActivity.class);
                i.putExtra("name", (CharSequence) RecentlyViewedList.get(position).getName());
                i.putExtra("shangpin", (CharSequence) RecentlyViewedList.get(position).getshangpin());
                i.putExtra("price", (CharSequence) RecentlyViewedList.get(position).getprice());
                i.putExtra("time", (CharSequence) RecentlyViewedList.get(position).gettime());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return RecentlyViewedList.size();
    }

    public  static class RecentlyViewedViewHolder extends RecyclerView.ViewHolder{

        TextView name,shangpin,price,time;

        public RecentlyViewedViewHolder(@NonNull View itemView) {
            super(itemView);

            shangpin = itemView.findViewById(R.id.sp);
            price = itemView.findViewById(R.id.jg);
        }
    }

}