package com.example.cake.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.cake.utils.Post;
import com.example.cake.R;
import com.example.cake.adapter.CartViewedAdapter;
import com.example.cake.entity.CartViewed;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class CartActivity extends AppCompatActivity implements CartViewedAdapter.TotalSumListener {

    private String name,result,dg,price,img;
    private int num,sum=0;
    private Handler handler; // 定义一个android.os.Handler对象
    List<CartViewed> RecentlyViewedList = new ArrayList<>();
    RecyclerView  recentlyViewedRecycler;
    CartViewedAdapter recentlyViewedAdapter;
    private TextView totalSumTextView,deleteButton;
    private LinearLayout dd,wd,zhuye;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        recentlyViewedRecycler = findViewById(R.id.recently_item);
        totalSumTextView = findViewById(R.id.tv_total_price);
        deleteButton = findViewById(R.id.tv_delete);

        deleteButton.setOnClickListener(v -> {
            List<CartViewed> updatedItems = new ArrayList<>();
            for (CartViewed item : RecentlyViewedList) {
                if (!item.isChecked()) {
                    updatedItems.add(item);
                }
            }
            RecentlyViewedList.clear();
            RecentlyViewedList.addAll(updatedItems);
            recentlyViewedAdapter.notifyDataSetChanged();
        });

        dd = findViewById(R.id.dd);
        dd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CartActivity.this, OrderActivity.class);
                i.putExtra("name",name);
                startActivity(i);
                finish();
            }
        });

        wd = findViewById(R.id.wd);
        wd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CartActivity.this, PerActivity.class);
                i.putExtra("name",name);
                startActivity(i);
                finish();
            }
        });

        zhuye = findViewById(R.id.zy);
        zhuye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CartActivity.this, CakeActivity.class);
                i.putExtra("name",name);
                startActivity(i);
                finish();
            }
        });

        Intent i = getIntent();
        name = i.getStringExtra("name");

        handler = new Handler() {
            @Override
            public void handleMessage(Message msg) {

                Log.i("result00000",result );
                if ("".equals(result)==false) { //
                    try {
                        JSONArray jsonArray = new JSONArray(result);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            name = jsonObject1.getString("name");
                            dg = jsonObject1.getString("dg");
                            price = jsonObject1.getString("price");
                            img = jsonObject1.getString("img");
                            num = jsonObject1.getInt("num");

                            sum+= num*Integer.parseInt(price);
                            RecentlyViewedList.add(new CartViewed(name, dg, price,  img, num));
                            setRecentlyViewedRecycler(RecentlyViewedList);
                        }
                        // 更新总和
                        updateTotalSum();
                        recentlyViewedAdapter.setTotalSumListener(CartActivity.this);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Log.i("result11111",result );
                }
                super.handleMessage(msg);
            }
        };

        new Thread(new Runnable() {  // 创建一个新线程
            public void run() {
                String params="";
                try {
                    params = "name=" + URLEncoder.encode(name, "utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                Log.i("params",params);
                result= Post.Send(params,"CartServlet");    //调用send()方法，
                //result=sendClass.send1("courseServlet",map);
                Message m = handler.obtainMessage();    // 获取一个Message
                handler.sendMessage(m);      // 发送消息
            }
        }).start();     // 开启线程

    }

    private void setRecentlyViewedRecycler(List<CartViewed> recentlyViewedDataList) {
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(CartActivity.this,1);
        recentlyViewedRecycler.setLayoutManager(layoutManager);
        recentlyViewedAdapter = new CartViewedAdapter(this,recentlyViewedDataList);
        recentlyViewedRecycler.setAdapter(recentlyViewedAdapter);
    }

    // 当RecyclerView中的数据发生变化时调用此方法
    private void updateTotalSum() {
        double totalSum = recentlyViewedAdapter.calculateTotalSum();
        totalSumTextView.setText("￥ " + totalSum);
    }

    @Override
    public void onTotalSumChanged(double totalSum) {
        totalSumTextView.setText("￥ " + totalSum);
    }

}