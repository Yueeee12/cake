package com.example.cake.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.cake.utils.PostUtil;
import com.example.cake.R;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class RegisterActivity extends AppCompatActivity {
    EditText username = null;
    EditText password = null;
    EditText tel = null;
    Button register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        tel = findViewById(R.id.tel);
        register=findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {  //实现单击查询按钮，发送信息与服务器交互
            @Override
            public void onClick(View v) {
                new Thread(){
                    @Override
                    public void run() {

                        String data="";
                        try {
                            data = "username="+ URLEncoder.encode(username.getText().toString(), "UTF-8")+
                                    "&password="+ URLEncoder.encode(password.getText().toString(), "UTF-8")+
                                    "&tel="+ URLEncoder.encode(tel.getText().toString(), "UTF-8");
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }

                        Log.i("data",data);
                        String request = PostUtil.Post("RegisterServlet",data);

                        int msg = 0;
                        if(request.equals("成功")){
                            msg = 2;
                        }
                        if(request.equals("已存在")){
                            msg = 1;
                        }
                        hand.sendEmptyMessage(msg);
                    }
                }.start();
            }
        });
    }

    final Handler hand = new Handler()
    {
        @Override
        public void handleMessage(Message msg) {
            if(msg.what == 0)
            {
                Toast.makeText(getApplicationContext(),"注册失败",Toast.LENGTH_LONG).show();
            }
            if(msg.what == 1)
            {
                Toast.makeText(getApplicationContext(),"该账号已经存在，请换一个账号",Toast.LENGTH_LONG).show();
            }
            if(msg.what == 2)
            {
                //startActivity(new Intent(getApplication(),MainActivity.class));
                Intent intent = new Intent();
                //将想要传递的数据用putExtra封装在intent中
                intent.putExtra("a","註冊");
                setResult(RESULT_CANCELED,intent);
                finish();
            }
        }
    };
}