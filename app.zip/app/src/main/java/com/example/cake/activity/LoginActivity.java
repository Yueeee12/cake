package com.example.cake.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cake.utils.PostUtil;
import com.example.cake.R;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class LoginActivity extends AppCompatActivity {

    private Button login;
    private TextView register;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        EditText EditTextname = (EditText)findViewById(R.id.username);
        EditText EditTextpassword = (EditText)findViewById(R.id.password);
        login=findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {  //实现单击查询按钮，发送信息与服务器交互
            @Override
            public void onClick(View v) {
                String a = EditTextname.getText().toString();
                String b = EditTextpassword.getText().toString();
                if(TextUtils.isEmpty(a) || TextUtils.isEmpty(b))
                {
                    new AlertDialog.Builder(LoginActivity.this)
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .setTitle("注意")
                            .setMessage("输入信息不能为空")
                            .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int whichButton) {
                                }
                            }).create().show();
                }
                new Thread(){
                    @Override
                    public void run() {
                        String data = "";
                        try {
                            data = "username=" + URLEncoder.encode(EditTextname.getText().toString(), "UTF-8") +
                                    "&password=" + URLEncoder.encode(EditTextpassword.getText().toString(), "UTF-8");
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                        Log.i("data", data);
                        String request = PostUtil.Post("LoginServlet", data);
                        int msg = 0;
                        if (request.equals("成功")) {
                            msg = 1;
                            //监听按钮，如果点击，就跳转
                            Intent intent = new Intent();
                            intent.putExtra("name",a);
                            //前一个（MainActivity.this）是目前页面，后面一个是要跳转的下一个页面
                            intent.setClass(LoginActivity.this, CakeActivity.class);
                            startActivity(intent);
                        }
                        hand1.sendEmptyMessage(msg);
                    }
                }.start();

            }
        });

        register=findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //监听按钮，如果点击，就跳转
                Intent intent = new Intent();
                //前一个（MainActivity.this）是目前页面，后面一个是要跳转的下一个页面
                intent.setClass(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

    }

    final Handler hand1 = new Handler()
    {
        @Override
        public void handleMessage(Message msg) {

            if(msg.what == 1)
            {
                Toast.makeText(getApplicationContext(),"登录成功",Toast.LENGTH_LONG).show();

            }
            else
            {
                Toast.makeText(getApplicationContext(),"登录失败",Toast.LENGTH_LONG).show();
            }
        }
    };

}