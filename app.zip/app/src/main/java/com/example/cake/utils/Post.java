package com.example.cake.utils;

import android.util.Log;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Post {
    public static String Post()
    {
        String ip = "http://192.168.0.106:8080/Cake/";
        return ip;
    }

    public static String Send(String params, String data) {
        String Url = Post.Post();
        String target = Url + data;    //要提交的服务器地址
        String result="";
        URL url;
        try {
            url = new URL(target);  //创建URL对象
            HttpURLConnection urlConn = (HttpURLConnection) url.openConnection();  // 创建一个HTTP连接
            urlConn.setRequestMethod("POST"); // 指定使用POST请求方式
            urlConn.setDoInput(true); // 向连接中写入数据
            urlConn.setDoOutput(true); // 从连接中读取数据
            urlConn.setUseCaches(false); // 禁止缓存
            urlConn.setInstanceFollowRedirects(true);    //自动执行HTTP重定向
            urlConn.setRequestProperty("Content-Type",
                    "application/x-www-form-urlencoded"); // 设置内容类型
            //Log.i("username", edit_Username.getText().toString());
            DataOutputStream out = new DataOutputStream(
                    urlConn.getOutputStream()); // 获取输出流

            //连接要提交的数据
            out.writeBytes(params.toString());//将要传递的数据写入数据输出流
            out.flush();    //输出缓存
            out.close();    //关闭数据输出流
            Log.i("HttpURLConnection=", "sdf");
            Log.i("urlConn.getResponseCode", String.valueOf(urlConn.getResponseCode()));
            if (urlConn.getResponseCode() == HttpURLConnection.HTTP_OK) {  //判断是否响应成功
                Log.i("urlConngetResponseCode=", String.valueOf(urlConn.getResponseCode()));
                InputStreamReader in = new InputStreamReader(
                        urlConn.getInputStream()); // 获得读取的内容
                BufferedReader buffer = new BufferedReader(in); // 获取输入流对象
                String inputLine = null;

                while ((inputLine = buffer.readLine()) != null) {  //通过循环逐行读取输入流中的内容
                    result += inputLine;
                }
                in.close();    //关闭字符输入流
            }
            Log.i("result=", result);
            urlConn.disconnect();    //断开连接
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }
}
