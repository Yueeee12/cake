package com.example.cake.activity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.cake.utils.Post;
import com.example.cake.R;
import com.example.cake.adapter.CakeViewedAdapter;
import com.example.cake.entity.CakeViewed;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class CakeActivity extends AppCompatActivity {

    private String name,id="1",result,dg,price,kucun,img;
    private TextView namea;
    private Handler handler; // 定义一个android.os.Handler对象
    List<CakeViewed> cakeViewedList = new ArrayList<>();
    RecyclerView  recentlyViewedRecycler;
    CakeViewedAdapter cakeViewedAdapter;
    private LinearLayout gwc,wd,dd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zhu);

        recentlyViewedRecycler = findViewById(R.id.recently_item);

        Intent i = getIntent();
        name = i.getStringExtra("name");
        namea = findViewById(R.id.name);
        namea.setText(name);

        gwc = findViewById(R.id.gwc);
        gwc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CakeActivity.this, CartActivity.class);
                i.putExtra("name",name);
                startActivity(i);
                finish();
            }
        });

        wd = findViewById(R.id.wd);
        wd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CakeActivity.this, PerActivity.class);
                i.putExtra("name",name);
                startActivity(i);
                finish();
            }
        });

        dd = findViewById(R.id.dd);
        dd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CakeActivity.this, OrderActivity.class);
                i.putExtra("name",name);
                startActivity(i);
                finish();
            }
        });

        handler = new Handler() {
            private Object MyAdpater;  //
            @SuppressLint("HandlerLeak")
            @Override
            public void handleMessage(Message msg) {

                Log.i("result00000",result );
                if ("".equals(result)==false) { //
                    try {
                        JSONArray jsonArray = new JSONArray(result);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                            dg = jsonObject1.getString("dg");
                            price = jsonObject1.getString("price");
                            img = jsonObject1.getString("img");
                            kucun = jsonObject1.getString("kucun");

                            cakeViewedList.add(new CakeViewed(name, dg, price,  img, kucun));
                            setRecentlyViewedRecycler(cakeViewedList);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Log.i("result11111",result );
                }
                super.handleMessage(msg);
            }
        };

        new Thread(new Runnable() {  // 创建一个新线程
            public void run() {
                String params="";
                try {
                    params = "id=" + URLEncoder.encode(id, "utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                Log.i("params",params);
                result= Post.Send(params,"CakeServlet");    //调用send()方法，
                Message m = handler.obtainMessage();    // 获取一个Message
                handler.sendMessage(m);      // 发送消息
            }
        }).start();     // 开启线程

    }

    private void setRecentlyViewedRecycler(List<CakeViewed> cakeViewedDataList) {
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(CakeActivity.this,2);
        recentlyViewedRecycler.setLayoutManager(layoutManager);
        cakeViewedAdapter = new CakeViewedAdapter(this, cakeViewedDataList);
        recentlyViewedRecycler.setAdapter(cakeViewedAdapter);
    }
}