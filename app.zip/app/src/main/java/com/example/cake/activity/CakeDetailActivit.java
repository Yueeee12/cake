package com.example.cake.activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.target.CustomTarget;
import com.bumptech.glide.request.transition.Transition;
import com.example.cake.utils.Post;
import com.example.cake.R;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CakeDetailActivit extends AppCompatActivity {

    ImageView img, back;
    TextView pname, pprice, pkc;
    String name, image, price,kucun,dg,num="1";
    private Bitmap imgBitmap = null;
    private Button gwc,gm;
    String result=null;
    Handler handler; // 定义一个android.os.Handler对象

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cakedetail);

        Intent i = getIntent();
        dg = i.getStringExtra("dg");
        image = i.getStringExtra("image");
        price = i.getStringExtra("price");
        kucun = i.getStringExtra("kucun");
        name = i.getStringExtra("name");

        initViews();

        pname.setText(dg);
        pprice.setText(price);
        pkc.setText(kucun);
        requestWebPhotoBitmap(image);


        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CakeDetailActivit.this, CakeActivity.class);
                i.putExtra("name",name);
                startActivity(i);
                finish();
            }
        });


        gwc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                handler = new Handler(Looper.getMainLooper()) {  //
                    @Override
                    public void handleMessage(@NonNull Message msg) {
                        //Log.i("result00000",result );
                        Toast.makeText(CakeDetailActivit.this, "添加成功",Toast.LENGTH_SHORT).show();
                        super.handleMessage(msg);
                    }
                };

                new Thread(new Runnable() {  // 创建一个新线程
                    public void run() {
                        String params = "";
                        try {
                            params = "name=" + URLEncoder.encode(name, "utf-8")    //连接要提交的数据
                                    + "&dg=" + URLEncoder.encode(dg, "utf-8")
                                    + "&image=" + URLEncoder.encode(image, "utf-8")
                                    + "&num=" + URLEncoder.encode(num, "utf-8")
                                    + "&price=" + URLEncoder.encode(price, "utf-8");
                        } catch (UnsupportedEncodingException e) {
                            e.printStackTrace();
                        }
                        Log.i("params", params);
                        result = Post.Send(params, "AddServlet");    //调用send()方法，
                        Message m = handler.obtainMessage();    // 获取一个Message
                        handler.sendMessage(m);      // 发送消息
                    }
                }).start();     // 开启线程
            }
        });

        gm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy年MM月dd日");// HH:mm:ss
                    // 获取当前时间
                    Date date = new Date(System.currentTimeMillis());

                    handler = new Handler() {  //
                        @Override
                        public void handleMessage(Message msg) {
                            //Log.i("result00000",result );
                            Toast.makeText(CakeDetailActivit.this, "添加成功",Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(CakeDetailActivit.this, CakeActivity.class);
                            i.putExtra("name",name);
                            startActivity(i);
                            super.handleMessage(msg);
                        }
                    };

                    new Thread(new Runnable() {  // 创建一个新线程
                        public void run() {
                            String params = "";
                            try {
                                params = "name=" + URLEncoder.encode(name, "utf-8")    //连接要提交的数据
                                        + "&shangpin=" + URLEncoder.encode(dg + "1", "utf-8")
                                        + "&time=" + URLEncoder.encode(simpleDateFormat.format(date), "utf-8")
                                        + "&price=" + URLEncoder.encode(price, "utf-8");
                            } catch (UnsupportedEncodingException e) {
                                e.printStackTrace();
                            }
                            Log.i("params", params);
                            result = Post.Send(params, "BuyServlet");    //调用send()方法，
                            Message m = handler.obtainMessage();    // 获取一个Message
                            handler.sendMessage(m);      // 发送消息
                        }
                    }).start();     // 开启线程
            }
        });
    }

    private void initViews() {
        pname = findViewById(R.id.productName);
        pprice = findViewById(R.id.prodDesc);
        pkc = findViewById(R.id.pkc);
        img = findViewById(R.id.big);
        back = findViewById(R.id.imageView);
        gwc = findViewById(R.id.gwc);
        gm = findViewById(R.id.gm);
    }

    private void requestWebPhotoBitmap(String imgUrl) {
        Glide.with(CakeDetailActivit.this).asBitmap().load(imgUrl).into(new CustomTarget<Bitmap>() {
            @SuppressLint("ClickableViewAccessibility")
            @Override
            public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                imgBitmap = resource;
                img.setImageBitmap(imgBitmap);
            }

            @Override
            public void onLoadCleared(@Nullable Drawable placeholder) {

            }
        });
    }
}