package com.example.cake.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.cake.utils.Post;
import com.example.cake.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

public class PerActivity extends AppCompatActivity {

    String name,result,mm,tel;
    private Button dianji;
    String params="";
    private Handler handler; // 定义一个android.os.Handler对象
    EditText Mima,Tel;
    private TextView Name;
    private LinearLayout gwc,zhuye,dd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person);

        Intent i = getIntent();
        name = i.getStringExtra("name");

        Name = (TextView) findViewById(R.id.name);
        Mima = (EditText)findViewById(R.id.mm);
        Tel = (EditText)findViewById(R.id.tel);

        gwc = findViewById(R.id.gwc);
        gwc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PerActivity.this, CartActivity.class);
                i.putExtra("name",name);
                startActivity(i);
                finish();
            }
        });

        dd = findViewById(R.id.dd);
        dd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PerActivity.this, OrderActivity.class);
                i.putExtra("name",name);
                startActivity(i);
                finish();
            }
        });

        zhuye = findViewById(R.id.zhuye);
        zhuye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(PerActivity.this, CakeActivity.class);
                i.putExtra("name",name);
                startActivity(i);
                finish();
            }
        });

        handler = new Handler() {  //
            @Override
            public void handleMessage(Message msg) {
                Log.i("result00000", result);
                if ("".equals(result) == false) { //
                    Log.i("contents-1111", result);
                    try {
                        if (result!= null) {
                            //json方式接收服务器传来的数据
                            JSONObject jsonObject = new JSONObject(result);
                            name = jsonObject.getString("username").toString();
                            mm = jsonObject.getString("password").toString();
                            tel = jsonObject.getString("tel").toString();

                            Name.setText(name);
                            Tel.setText(tel);
                            Mima.setText(mm);

                        } else {
                            // 如果数据为空，则提供一个默认值
                            JSONObject jsonObject = (result != null) ? new JSONObject(result) : new JSONObject();
                        }
                        result = "";
                    } catch (JSONException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
                super.handleMessage(msg);
            }
        };

        new Thread(new Runnable() {  // 创建一个新线程
            public void run() {
                String params="";
                try {
                    params = "name=" + URLEncoder.encode(name, "utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                Log.i("params",params);
                result= Post.Send(params,"PersonalServlet");    //调用send()方法，
                //result=sendClass.send1("courseServlet",map);
                Message m = handler.obtainMessage();    // 获取一个Message
                handler.sendMessage(m);      // 发送消息
            }
        }).start();     // 开启线程

        dianji=(Button)findViewById(R.id.update);
        dianji.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                // TODO Auto-generated method stub
                try {
                    params = "username=" + URLEncoder.encode(Name.getText().toString(), "utf-8")
                            + "&password=" + URLEncoder.encode(Mima.getText().toString(), "utf-8")
                            + "&tel=" + URLEncoder.encode(Tel.getText().toString(), "utf-8");
                } catch (UnsupportedEncodingException e) {
                    e.printStackTrace();
                }
                Log.i("params",params);
                handler = new Handler() {  //
                    @Override
                    public void handleMessage(Message msg) {
                        //Log.i("result00000",result );
                        if ("".equals(Tel)==false&&"".equals(Mima)==false) { //
                            Log.i("result11111000000",result );
                            Toast.makeText(PerActivity.this, "信息修改成功",Toast.LENGTH_SHORT).show();
                        }else {
                            Toast.makeText(PerActivity.this, "信息修改失败",Toast.LENGTH_SHORT).show();
                            new AlertDialog.Builder(PerActivity.this)
                                    .setIcon(android.R.drawable.ic_dialog_alert)
                                    .setTitle("注意")
                                    .setMessage("信息不能为空")
                                    .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int whichButton) {
                                        }
                                    }).create().show();
                        }
                        super.handleMessage(msg);
                    }
                };
                new Thread(new Runnable() {  // 创建一个新线程
                    public void run() {
                        result= Post.Send(params,"PermodifiServlet");    //调用send()方法，
                        Message m = handler.obtainMessage();    // 获取一个Message
                        handler.sendMessage(m);      // 发送消息
                    }
                }).start();
            }
        });

    }
}