package com.example.cake.entity;

public class CartViewed {

    Object name;
    Object dg;
    String price;
    Object img;
    int num;
    private boolean isChecked;

    public CartViewed(Object name, Object dg, String price, Object img, int num) {
        this.name = name;
        this.dg = dg;
        this.img = img;
        this.price = price;
        this.num = num;
        this.isChecked = false; // 默认不选中
    }

    public Object getName() {
        return name;
    }

    public void setName(Object name) {
        this.name = name;
    }

    public Object getdg() {
        return dg;
    }

    public void setdg(Object dg) {
        this.dg = dg;
    }

    public String getprice() {
        return price;
    }

    public void setprice(String price) {
        this.price = price;
    }

    public Object getimg() {
        return img;
    }

    public void setimg(Object simg) {
        this.img = img;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getNum() {
        return num;
    }

    public boolean isChecked() {
        return isChecked;
    }

    public void setChecked(boolean checked) {
        isChecked = checked;
    }

}
