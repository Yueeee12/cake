package com.example.cake.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.cake.R;

public class OrderDetailActivity extends AppCompatActivity {

    ImageView img, back;
    TextView pname, pprice, pkc;
    String name, sp, price,time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orderdetail);

        Intent i = getIntent();
        name = i.getStringExtra("name");
        sp = i.getStringExtra("shangpin");
        price = i.getStringExtra("price");
        time = i.getStringExtra("time");

        pname = findViewById(R.id.sp);
        pprice = findViewById(R.id.jg);
        pkc = findViewById(R.id.sj);

        pname.setText(sp);
        pprice.setText(price);
        pkc.setText(time);

        back = findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(OrderDetailActivity.this, OrderActivity.class);
                i.putExtra("name",name);
                startActivity(i);
                finish();
            }
        });

    }
}